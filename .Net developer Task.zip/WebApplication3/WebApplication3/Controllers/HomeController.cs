﻿using Microsoft.AspNetCore.Mvc;
using WebApplication2.Repositry;
using WebApplication2.RequestDto;

namespace WebApplication2.Controllers
{
    public class HomeController : Controller
    {
        private readonly IEncryptDecrypt iencryptDecrypt;

        public HomeController(IEncryptDecrypt encryptDecrypt)
        {
            iencryptDecrypt = encryptDecrypt;
        }

        [HttpGet]
        [Route("GetData")]

        public IActionResult GetAllData()
        {
            var d =  iencryptDecrypt.GetAllData();
            return Ok(d);
        }

        [HttpPost]
        [Route("adddata")]
        public IActionResult postData([FromForm] AddData data)
        {
            //var d = iencryptDecrypt.AddData(data);
            //return Ok(d);

            if (!ModelState.IsValid)
            {
                return BadRequest(ModelState);
            }

            var result = iencryptDecrypt.AddData(data);
            return Ok(result);
        }



        [HttpPost]
        [Route("UpdateData")]
        public IActionResult Deleteata(UpdateData data)
        {
            var d = iencryptDecrypt.UpdateData(data);
            return Ok(d);
        }

        [HttpDelete]
        [Route("DeleteData")]
        public IActionResult Deleteata(int data)
        {
            var d = iencryptDecrypt.DeleteData(data);
            return Ok(d);
        }


        [HttpDelete]
        [Route("SoftDeleteData")]
        public IActionResult SoftDeleteata(int data)
        {
            var d = iencryptDecrypt.SoftDeleteData(data);
            return Ok(d);
        }
        public IActionResult Index()
        {
            return View();
        }
    }
}
