﻿using WebApplication2.RequestDto;
using WebApplication2.ResponseDto;

namespace WebApplication2.Repositry
{
    public interface IEncryptDecrypt
    {

        public List<GetData> GetAllData();

        public ResponseModel AddData(AddData data);

        public ResponseModel DeleteData(int id);

        public ResponseModel UpdateData( UpdateData data);

        public ResponseModel SoftDeleteData(int id);


    }
}
