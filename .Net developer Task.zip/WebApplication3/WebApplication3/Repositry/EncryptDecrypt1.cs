﻿using Microsoft.EntityFrameworkCore;
using System.Security.Cryptography;
using System.Text;
using WebApplication2.RequestDto;
using WebApplication2.ResponseDto;
using WebApplication3.Models;

namespace WebApplication2.Repositry
{
    public class EncryptDecrypt1 : IEncryptDecrypt
    {
        private readonly princeContext _context;
        public EncryptDecrypt1(princeContext context)
        {
            _context = context;
        }


    public ResponseModel AddData(AddData data)
        {


            ResponseModel responseModel = new ResponseModel();
            EncryptedDatum datum = new EncryptedDatum();

            // Encrypt the data before storing it
            string encryptedData = CryptoEngine.Encrypt(data.Data, "sjchbsd123213wj12hcbdshbch");

            datum.Data = encryptedData;
            datum.Id = data.Id;
            datum.Timestamp = data.Timestamp;

            _context.EncryptedData.Add(datum);
            _context.SaveChanges();

            responseModel.ResponseCode = 200;
            responseModel.ResponseMessage = "data added successfully";
            responseModel.Status = "success";
            return responseModel;


            //ResponseModel responseModel = new ResponseModel();
            ////var data1 = _context.EncryptedDatas.ToList();
            //EncryptedDatum datum = new EncryptedDatum();


            //datum.Data = data.Data;
            //datum.Id = data.Id;
            //datum.Timestamp = data.Timestamp;


            //_context.EncryptedData.Add(datum);
            //_context.SaveChanges();
            //responseModel.ResponseCode = 200;
            //responseModel.ResponseMessage = "data addes sucess";
            //responseModel.Status = "success";
            //return responseModel;
        }

        public ResponseModel DeleteData(int id)
        {
            var data = _context.EncryptedData.SingleOrDefault(x => x.Id == id);
            ResponseModel responseModel = new ResponseModel();

            if (data != null)
            {
                _context.EncryptedData.Remove(data);
                _context.SaveChanges();
                responseModel.ResponseMessage = "data deleted success";
                responseModel.Status = "success";
                responseModel.ResponseCode=200;

            }
            else
            {
                responseModel.ResponseMessage = "data not found";
                responseModel.Status = "error";
                responseModel.ResponseCode = 401;
            }
            return responseModel;

        }

        public List<GetData> GetAllData()
        {


            List<GetData> getData = new List<GetData>();

            var data = _context.EncryptedData.ToList();

            foreach (var data1 in data)
            {
                // Decrypt the data before returning it
                string decryptedData = CryptoEngine.Decrypt(data1.Data, "sjchbsd123213wj12hcbdshbch");

                getData.Add(new GetData
                {
                    Data = decryptedData,
                    Timestamp = data1.Timestamp
                });
            }

            return getData;



            //List<GetData> getData = new List<GetData>();
            //var data = (from data1 in _context.EncryptedData
            //            select new GetData
            //            {
            //                Data = data1.Data,
            //                Timestamp = data1.Timestamp
            //            }).ToList();
            //getData = data;
            //return getData;

        }

        public ResponseModel SoftDeleteData(int id)
        {

            var d = _context.EncryptedData.SingleOrDefault(x=>x.Id==id);
            ResponseModel responseModel = new ResponseModel();
            if (d!=null)
            {
                d.IsDeleted = true;
                _context.SaveChanges();
                responseModel.ResponseMessage = "deleted success";
                responseModel.ResponseCode = 200;
                responseModel.Status = "success";   
            }
            else
            {
                responseModel.Status = "error";
                responseModel.ResponseCode = 401;
                responseModel.ResponseMessage = "whether data is alresy deleted or not found";
            }
            return responseModel;
        }

        public ResponseModel UpdateData(UpdateData data1)
        {
            EncryptedDatum encryptedDatum = new EncryptedDatum();
            ResponseModel responseModel = new ResponseModel();
            var d = _context.EncryptedData.SingleOrDefault(data => data.Id == data1.Id);
            if(d != null)
            {
                encryptedDatum.Data = data1.Data;
                encryptedDatum.Timestamp = data1.Timestamp;
                _context.SaveChanges();
                responseModel.Status="success";
                responseModel.ResponseMessage = "data update success";
                responseModel.ResponseCode = 200;
            }
            return responseModel;
        }
    }



    public class CryptoEngine
    {
        public static string Encrypt(string input, string key)
        {
            byte[] inputArray = UTF8Encoding.UTF8.GetBytes(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateEncryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return Convert.ToBase64String(resultArray, 0, resultArray.Length);
        }
        public static string Decrypt(string input, string key)
        {
            byte[] inputArray = Convert.FromBase64String(input);
            TripleDESCryptoServiceProvider tripleDES = new TripleDESCryptoServiceProvider();
            tripleDES.Key = UTF8Encoding.UTF8.GetBytes(key);
            tripleDES.Mode = CipherMode.ECB;
            tripleDES.Padding = PaddingMode.PKCS7;
            ICryptoTransform cTransform = tripleDES.CreateDecryptor();
            byte[] resultArray = cTransform.TransformFinalBlock(inputArray, 0, inputArray.Length);
            tripleDES.Clear();
            return UTF8Encoding.UTF8.GetString(resultArray);
        }
    }



}






//---------------Waste code ----------------------------








//public ResponseModel AddData(AddData data)
//{
//    ResponseModel responseModel = new ResponseModel();
//    EncryptedDatum datum = new EncryptedDatum();

//    // Encrypt the data before storing it
//    string encryptedData = CryptoEngine.Encrypt(data.Data, "yourEncryptionKey");

//    datum.Data = encryptedData;
//    datum.Id = data.Id;
//    datum.Timestamp = data.Timestamp;

//    _context.EncryptedData.Add(datum);
//    _context.SaveChanges();

//    responseModel.ResponseCode = 200;
//    responseModel.ResponseMessage = "data added successfully";
//    responseModel.Status = "success";
//    return responseModel;
//}

//public List<GetData> GetAllData()
//{
//List<GetData> getData = new List<GetData>();

//var data = _context.EncryptedData.ToList();

//foreach (var data1 in data)
//{
//    // Decrypt the data before returning it
//    string decryptedData = CryptoEngine.Decrypt(data1.Data, "yourEncryptionKey");

//    getData.Add(new GetData
//    {
//        Data = decryptedData,
//        Timestamp = data1.Timestamp
//    });
//}

//return getData;
//}

// ... existing code ...


