﻿namespace WebApplication2.RequestDto
{
    public class AddData
    {


        public string? Data { get; set; }
        public TimeSpan? Timestamp { get; set; }
        public int Id { get; set; }


    }
}
