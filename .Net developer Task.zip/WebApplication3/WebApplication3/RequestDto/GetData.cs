﻿namespace WebApplication2.RequestDto
{
    public class GetData 
    {
        public string? Data { get; set; }
        //public bool? InitializationVector { get; set; }
        public TimeSpan? Timestamp { get; set; }
    }
}
