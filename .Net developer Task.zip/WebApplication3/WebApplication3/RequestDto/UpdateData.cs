﻿namespace WebApplication2.RequestDto
{
    public class UpdateData
    {
        public int Id { get; set; }
        public string? Data { get; set; }
        public bool? InitializationVector { get; set; }
        public TimeSpan? Timestamp { get; set; }
    }
}
