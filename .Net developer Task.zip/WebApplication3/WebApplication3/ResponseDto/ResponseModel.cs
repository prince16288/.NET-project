﻿namespace WebApplication2.ResponseDto
{
    public class ResponseModel
    { 
        public int? ResponseCode { get; set; }
        public string? Status { get; set; }
        public string? ResponseMessage { get; set; }
    }
}
