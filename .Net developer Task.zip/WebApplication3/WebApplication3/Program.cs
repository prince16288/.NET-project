using Microsoft.EntityFrameworkCore;
using WebApplication2.Repositry;
using WebApplication3.Models;

var builder = WebApplication.CreateBuilder(args);


//DESKTOP - 72M1U74\SQLEXPRESS
builder.Services.AddScoped<IEncryptDecrypt, EncryptDecrypt1>();
builder.Services.AddDbContext<princeContext>(item => item.UseSqlServer("Server=DESKTOP-72M1U74\\SQLEXPRESS;Database=prince;UID=prince;PWD=p1628;"));

//builder.Services.AddDbContext<princeContext>(item => item.UseSqlServer("Server=192.168.0.240;Database=sdirectdb;UID=sdirectdb;PWD=sdirectdb;"));
builder.Services.AddCors(p => p.AddPolicy("corsapp", builder =>
{
    builder
    .AllowAnyOrigin()
    .AllowAnyHeader()
    .AllowAnyMethod();
}));



// Add services to the container.

builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseAuthorization();

app.MapControllers();

app.UseCors("corsapp");
app.Run();
