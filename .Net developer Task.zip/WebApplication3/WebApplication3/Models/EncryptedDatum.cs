﻿using System;
using System.Collections.Generic;

namespace WebApplication3.Models
{
    public partial class EncryptedDatum
    {
        public int Id { get; set; }
        public string? Data { get; set; }
        public bool? InitializationVector { get; set; }
        public TimeSpan? Timestamp { get; set; }
        public bool? IsDeleted { get; set; }
    }
}
